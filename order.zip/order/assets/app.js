function formatMoney(n){
  n = Number(n || 0);
  return n.toLocaleString('ar-IQ');
}

function qs(id){ return document.getElementById(id); }

function showToast(msg){
  alert(msg);
}