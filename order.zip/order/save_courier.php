<?php
require_once __DIR__ . '/auth.php';
require_perm('courier');

if($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('courier.php');

$cfg = [
  "enabled" => isset($_POST['enabled']),
  "company_name" => trim($_POST['company_name'] ?? ''),
  "api_base_url" => trim($_POST['api_base_url'] ?? ''),
  "api_key" => trim($_POST['api_key'] ?? ''),
  "sender_name" => trim($_POST['sender_name'] ?? ''),
  "sender_phone" => trim($_POST['sender_phone'] ?? ''),
  "sender_city" => trim($_POST['sender_city'] ?? ''),
  "notes" => trim($_POST['notes'] ?? ''),
];

write_json(courier_path(), $cfg);
redirect('courier.php');