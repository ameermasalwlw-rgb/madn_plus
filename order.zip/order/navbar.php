<?php
require_once __DIR__ . '/auth.php';
require_login();
$u = current_user();
?>
<div class="topbar mb-4 d-flex align-items-center justify-content-between">
  <div class="brand">
    <div class="logo"><i class="fa-solid fa-box"></i></div>
    <div>
      <div>نظام الطلبات</div>
      <div class="small-note">مرحباً <?= htmlspecialchars($u['full_name'] ?: $u['username']) ?></div>
    </div>
  </div>

  <div class="d-flex align-items-center gap-2">
    <a class="btn btn-outline-secondary btn-fat" href="index.php">
      <i class="fa-solid fa-gauge"></i> الرئيسية
    </a>
    <a class="btn btn-outline-danger btn-fat" href="logout.php">
      <i class="fa-solid fa-right-from-bracket"></i> خروج
    </a>
  </div>
</div>