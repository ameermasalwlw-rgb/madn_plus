<?php
require_once __DIR__ . '/auth.php';
require_perm('products');

$products = read_json(products_path(), []);
if(!is_array($products)) $products = [];
$products = array_reverse($products);
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>المنتجات</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="assets/style.css" rel="stylesheet">
</head>
<body>
<div class="container container-max py-4">
  <?php include __DIR__ . '/navbar.php'; ?>

  <div class="panel mb-3 d-flex justify-content-between align-items-center">
    <div style="font-weight:900; font-size:18px;"><i class="fa-solid fa-boxes-stacked"></i> إضافة منتج</div>
    <a class="btn btn-outline-secondary btn-fat" href="index.php"><i class="fa-solid fa-ban"></i> إلغاء</a>
  </div>

  <div class="panel mb-3">
    <form class="row g-2" method="POST" action="save_product.php" enctype="multipart/form-data">
      <div class="col-lg-4">
        <label class="form-label">اسم المنتج</label>
        <input class="form-control field" name="name" required>
      </div>
      <div class="col-lg-2">
        <label class="form-label">العدد (مخزون)</label>
        <input class="form-control field" name="stock" value="0">
      </div>
      <div class="col-lg-2">
        <label class="form-label">التكلفة</label>
        <input class="form-control field" name="cost" value="0" required>
      </div>
      <div class="col-lg-2">
        <label class="form-label">سعر البيع</label>
        <input class="form-control field" name="sell" value="0" required>
      </div>
      <div class="col-lg-2">
        <label class="form-label">صورة</label>
        <input class="form-control field" type="file" name="image" accept="image/*">
      </div>

      <div class="col-12 d-flex gap-2">
        <button class="btn btn-success btn-fat"><i class="fa-solid fa-plus"></i> إضافة</button>
        <a class="btn btn-outline-secondary btn-fat" href="add_order.php"><i class="fa-solid fa-cart-plus"></i> إلى إضافة الطلب</a>
      </div>
    </form>
  </div>

  <div class="panel">
    <div style="font-weight:900" class="mb-2">قائمة المنتجات</div>
    <div class="table-wrap">
      <table class="table table-hover mb-0">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>الصورة</th>
            <th>الاسم</th>
            <th>المخزون</th>
            <th>التكلفة</th>
            <th>البيع</th>
          </tr>
        </thead>
        <tbody>
        <?php if(empty($products)): ?>
          <tr><td colspan="6" class="text-center p-4 small-note">لا توجد منتجات.</td></tr>
        <?php endif; ?>
        <?php foreach($products as $i=>$p): ?>
          <tr>
            <td><?= $i+1 ?></td>
            <td>
              <?php if(!empty($p['image'])): ?>
                <img src="<?= htmlspecialchars($p['image']) ?>" style="width:48px;height:48px;border-radius:12px;object-fit:cover;">
              <?php else: ?>
                <span class="small-note">—</span>
              <?php endif; ?>
            </td>
            <td style="font-weight:800"><?= htmlspecialchars($p['name'] ?? '') ?></td>
            <td><?= (int)($p['stock'] ?? 0) ?></td>
            <td><?= number_format((float)($p['cost'] ?? 0)) ?></td>
            <td><?= number_format((float)($p['sell'] ?? 0)) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>
</body>
</html>