<?php
require_once __DIR__ . '/auth.php';
require_perm('add_order');

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
  redirect('add_order.php');
}

$orders = read_json(orders_path(), []);
if(!is_array($orders)) $orders = [];

$order = [
  'id' => 'o_' . time() . '_' . rand(1000,9999),
  'created_at' => date('Y-m-d H:i:s'),
  'status' => 'new',

  'order_type' => trim($_POST['order_type'] ?? 'new'),
  'customer_name' => trim($_POST['customer_name'] ?? ''),
  'phone' => trim($_POST['phone'] ?? ''),
  'city' => trim($_POST['city'] ?? ''),
  'area' => trim($_POST['area'] ?? ''),
  'address' => trim($_POST['address'] ?? ''),
  'note' => trim($_POST['note'] ?? ''),

  'assigned_to' => trim($_POST['assigned_to'] ?? current_user()['username']),

  'items' => [],
  'total' => (float)($_POST['total'] ?? 0),
  'discount' => (float)($_POST['discount'] ?? 0),
  'paid' => (float)($_POST['paid'] ?? 0),
];

$itemsJson = $_POST['items_json'] ?? '[]';
$items = json_decode($itemsJson, true);
if(is_array($items)){
  foreach($items as $it){
    $order['items'][] = [
      'id' => $it['id'] ?? '',
      'name' => $it['name'] ?? '',
      'qty' => (float)($it['qty'] ?? 0),
      'cost' => (float)($it['cost'] ?? 0),
      'sell' => (float)($it['sell'] ?? 0),
    ];
  }
}

$orders[] = $order;
write_json(orders_path(), $orders);

redirect('orders.php?status=new&saved=1');