<?php
require_once __DIR__ . '/auth.php';
require_perm('dashboard');

$u = current_user();
$stats = user_stats($u['username']);

$ads = read_json(ads_path(), ["interval_ms"=>3000,"images"=>[]]);
$adsImages = $ads['images'] ?? [];
$intervalMs = (int)($ads['interval_ms'] ?? 3000);

// بطاقات النظام (تظهر حسب الصلاحيات)
$cards = [];

if(has_perm('add_order')){
  $cards[] = ['href'=>'add_order.php','icon'=>'fa-cart-plus','color'=>'icon-blue','title'=>'طلب جديد','sub'=>'إضافة طلب بسلة منتجات'];
}
if(has_perm('orders')){
  $cards[] = ['href'=>'orders.php?status=new','icon'=>'fa-bolt','color'=>'icon-green','title'=>'الطلبات الجديدة','sub'=>'عرض وإدارة الطلبات'];
  $cards[] = ['href'=>'orders.php?status=in_company','icon'=>'fa-building','color'=>'icon-orange','title'=>'عند الشركة','sub'=>'طلبات بانتظار التوصيل'];
  $cards[] = ['href'=>'orders.php?status=returned','icon'=>'fa-rotate-left','color'=>'icon-red','title'=>'الراجعة','sub'=>'طلبات راجعة/مسترجعة'];
}
if(has_perm('products')){
  $cards[] = ['href'=>'products.php','icon'=>'fa-boxes-stacked','color'=>'icon-blue','title'=>'المنتجات','sub'=>'إضافة منتجات وصور'];
}
if(has_perm('users')){
  $cards[] = ['href'=>'users.php','icon'=>'fa-users-gear','color'=>'icon-orange','title'=>'المستخدمين والصلاحيات','sub'=>'صلاحيات + تسديد + حذف'];
}
if(has_perm('courier')){
  $cards[] = ['href'=>'courier.php','icon'=>'fa-link','color'=>'icon-green','title'=>'ربط شركة التوصيل','sub'=>'بيانات الربط والإعدادات'];
}
if(has_perm('ads')){
  $cards[] = ['href'=>'ads.php','icon'=>'fa-bullhorn','color'=>'icon-red','title'=>'الإعلانات','sub'=>'صور تتقلب تلقائياً'];
}
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>لوحة التحكم</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="assets/style.css" rel="stylesheet">
</head>
<body>
  <div class="container container-max py-4">
    <?php include __DIR__ . '/navbar.php'; ?>

    <div class="row g-3 mb-4">
      <div class="col-lg-7">
        <div class="panel">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <div style="font-weight:800; font-size:18px;">إحصائياتك</div>
            <div class="small-note">حسب المستخدم: <?= htmlspecialchars($u['username']) ?></div>
          </div>

          <div class="row g-2">
            <div class="col-6 col-md-3">
              <div class="big-card">
                <div class="icon icon-green"><i class="fa-solid fa-bolt"></i></div>
                <div class="title"><?= (int)$stats['new'] ?></div>
                <div class="sub">طلبات جديدة</div>
              </div>
            </div>
            <div class="col-6 col-md-3">
              <div class="big-card">
                <div class="icon icon-orange"><i class="fa-solid fa-building"></i></div>
                <div class="title"><?= (int)$stats['in_company'] ?></div>
                <div class="sub">عند الشركة</div>
              </div>
            </div>
            <div class="col-6 col-md-3">
              <div class="big-card">
                <div class="icon icon-blue"><i class="fa-solid fa-truck-fast"></i></div>
                <div class="title"><?= (int)$stats['delivered'] ?></div>
                <div class="sub">واصل</div>
              </div>
            </div>
            <div class="col-6 col-md-3">
              <div class="big-card">
                <div class="icon icon-red"><i class="fa-solid fa-rotate-left"></i></div>
                <div class="title"><?= (int)$stats['returned'] ?></div>
                <div class="sub">راجع</div>
              </div>
            </div>
          </div>
          <hr class="soft my-3">
          <div class="d-flex align-items-center justify-content-between">
            <div style="font-weight:800;">أرباحك (تقديري)</div>
            <div style="font-weight:900; font-size:18px;"><?= number_format((float)$stats['profit']) ?></div>
          </div>
          <div class="small-note mt-1">الأرباح = (سعر البيع - التكلفة) × الكمية - الخصم</div>
        </div>
      </div>

      <div class="col-lg-5">
        <div class="panel">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <div style="font-weight:800; font-size:18px;">الإعلانات</div>
            <div class="small-note">تتقلب تلقائياً</div>
          </div>

          <div class="slider" id="adsSlider">
            <?php if(empty($adsImages)): ?>
              <div class="p-4 small-note">لا توجد صور إعلانات بعد. اذهب إلى صفحة الإعلانات وأضف صور.</div>
            <?php else: ?>
              <?php foreach($adsImages as $i=>$img): ?>
                <img src="<?= htmlspecialchars($img) ?>" class="<?= $i===0?'active':'' ?>">
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <div class="panel">
      <div class="d-flex align-items-center justify-content-between mb-3">
        <div style="font-weight:800; font-size:18px;">القائمة</div>
        <div class="small-note">أيقونات حسب الصلاحيات</div>
      </div>

      <div class="nav-cards">
        <?php foreach($cards as $c): ?>
          <a class="big-card" href="<?= htmlspecialchars($c['href']) ?>">
            <div class="icon <?= htmlspecialchars($c['color']) ?>"><i class="fa-solid <?= htmlspecialchars($c['icon']) ?>"></i></div>
            <div class="title"><?= htmlspecialchars($c['title']) ?></div>
            <div class="sub"><?= htmlspecialchars($c['sub']) ?></div>
          </a>
        <?php endforeach; ?>
      </div>
    </div>

  </div>

  <script>
    (function(){
      const slider = document.getElementById('adsSlider');
      if(!slider) return;
      const imgs = slider.querySelectorAll('img');
      if(!imgs || imgs.length === 0) return;
      let idx = 0;
      const interval = <?= (int)$intervalMs ?>;

      setInterval(() => {
        imgs[idx].classList.remove('active');
        idx = (idx + 1) % imgs.length;
        imgs[idx].classList.add('active');
      }, interval);
    })();
  </script>
</body>
</html>