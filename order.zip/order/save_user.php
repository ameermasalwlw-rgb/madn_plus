<?php
require_once __DIR__ . '/auth.php';
require_perm('users');

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
  redirect('users.php');
}

$users = read_json(users_path(), []);
if(!is_array($users)) $users = [];

$username = trim($_POST['username'] ?? '');
$full = trim($_POST['full_name'] ?? '');
$pass = trim($_POST['password'] ?? '');
$role = $_POST['role'] ?? 'user';

foreach($users as $u){
  if(($u['username'] ?? '') === $username){
    redirect('users.php'); // موجود مسبقاً
  }
}

$permArr = $_POST['perm'] ?? [];
$permMap = [
  'dashboard'=>false,'add_order'=>false,'orders'=>false,'products'=>false,'users'=>false,'courier'=>false,'ads'=>false
];
if(is_array($permArr)){
  foreach($permArr as $p){
    if(isset($permMap[$p])) $permMap[$p] = true;
  }
}

$users[] = [
  'id' => 'u_' . time() . '_' . rand(1000,9999),
  'username' => $username,
  'password_hash' => password_hash($pass, PASSWORD_BCRYPT),
  'full_name' => $full,
  'role' => $role,
  'permissions' => $permMap,
  'profit_total' => 0,
  'profit_settled' => 0
];

write_json(users_path(), $users);
redirect('users.php');