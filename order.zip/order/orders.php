<?php
require_once __DIR__ . '/auth.php';
require_perm('orders');

$u = current_user();
$orders = read_json(orders_path(), []);
if(!is_array($orders)) $orders = [];

$status = $_GET['status'] ?? '';
$q = trim($_GET['q'] ?? '');

$filtered = [];
foreach(array_reverse($orders) as $o){
  // غير admin يرى فقط طلباته
  if(($u['role'] ?? '') !== 'admin'){
    if(($o['assigned_to'] ?? '') !== $u['username']) continue;
  }

  if($status && ($o['status'] ?? '') !== $status) continue;

  if($q){
    $hay = mb_strtolower(($o['customer_name'] ?? '') . ' ' . ($o['phone'] ?? ''));
    if(mb_strpos($hay, mb_strtolower($q)) === false) continue;
  }

  $filtered[] = $o;
}

// تحديث حالة طلب
if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $id = $_POST['id'] ?? '';
  $newStatus = $_POST['new_status'] ?? 'new';

  foreach($orders as &$o){
    if(($o['id'] ?? '') === $id){
      // حماية صلاحيات: المستخدم لا يغير طلب ليس له (إلا admin)
      if(($u['role'] ?? '') !== 'admin' && ($o['assigned_to'] ?? '') !== $u['username']){
        break;
      }
      $o['status'] = $newStatus;
      $o['updated_at'] = date('Y-m-d H:i:s');
      break;
    }
  }
  unset($o);

  write_json(orders_path(), $orders);
  redirect('orders.php?status=' . urlencode($status) . '&q=' . urlencode($q));
}
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>الطلبات</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="assets/style.css" rel="stylesheet">
</head>
<body>
<div class="container container-max py-4">
  <?php include __DIR__ . '/navbar.php'; ?>

  <div class="panel mb-3">
    <div class="d-flex flex-wrap gap-2 align-items-center justify-content-between">
      <div style="font-weight:900; font-size:18px;">
        <i class="fa-solid fa-list-check"></i> الطلبات
        <?php if($status): ?>
          <span class="badge-soft <?= status_badge_class($status) ?> ms-2"><?= status_label($status) ?></span>
        <?php endif; ?>
      </div>

      <a class="btn btn-outline-secondary btn-fat" href="index.php"><i class="fa-solid fa-ban"></i> إلغاء</a>
    </div>

    <hr class="soft my-3">

    <form class="row g-2" method="GET">
      <input type="hidden" name="status" value="<?= htmlspecialchars($status) ?>">
      <div class="col-lg-8">
        <input class="form-control field" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="بحث باسم الزبون أو رقم الهاتف...">
      </div>
      <div class="col-lg-4 d-flex gap-2">
        <button class="btn btn-primary btn-fat w-50"><i class="fa-solid fa-magnifying-glass"></i> بحث</button>
        <a class="btn btn-outline-secondary btn-fat w-50" href="orders.php?status=<?= htmlspecialchars($status) ?>"><i class="fa-solid fa-eraser"></i> مسح</a>
      </div>
    </form>
  </div>

  <div class="table-wrap">
    <table class="table table-hover mb-0">
      <thead class="table-light">
      <tr>
        <th>#</th>
        <th>الزبون</th>
        <th>الهاتف</th>
        <th>العنوان</th>
        <th>الحالة</th>
        <th>المسؤول</th>
        <th>الإجمالي</th>
        <th>تغيير الحالة</th>
      </tr>
      </thead>
      <tbody>
      <?php if(empty($filtered)): ?>
        <tr><td colspan="8" class="text-center p-4 small-note">لا توجد طلبات مطابقة.</td></tr>
      <?php endif; ?>

      <?php foreach($filtered as $i=>$o): ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td style="font-weight:800"><?= htmlspecialchars($o['customer_name'] ?? '') ?></td>
          <td><?= htmlspecialchars($o['phone'] ?? '') ?></td>
          <td class="small-note"><?= htmlspecialchars(($o['city'] ?? '').' - '.($o['area'] ?? '').' - '.($o['address'] ?? '')) ?></td>
          <td>
            <span class="badge-soft <?= status_badge_class($o['status'] ?? 'new') ?>">
              <?= status_label($o['status'] ?? 'new') ?>
            </span>
          </td>
          <td><?= htmlspecialchars($o['assigned_to'] ?? '') ?></td>
          <td><?= number_format((float)($o['total'] ?? 0)) ?></td>
          <td>
            <form method="POST" class="d-flex gap-2">
              <input type="hidden" name="id" value="<?= htmlspecialchars($o['id']) ?>">
              <select class="form-select field" name="new_status">
                <option value="new" <?= ($o['status']??'')==='new'?'selected':'' ?>>جديد</option>
                <option value="in_company" <?= ($o['status']??'')==='in_company'?'selected':'' ?>>عند الشركة</option>
                <option value="delivered" <?= ($o['status']??'')==='delivered'?'selected':'' ?>>واصل</option>
                <option value="returned" <?= ($o['status']??'')==='returned'?'selected':'' ?>>راجع</option>
              </select>
              <button class="btn btn-success btn-fat"><i class="fa-solid fa-check"></i></button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

</div>
</body>
</html>