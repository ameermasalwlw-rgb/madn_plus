<?php
require_once __DIR__ . '/auth.php';
require_perm('users');

$users = read_json(users_path(), []);
if(!is_array($users)) $users = [];

$orders = read_json(orders_path(), []);
if(!is_array($orders)) $orders = [];

function calc_user_profit($username, $orders){
  $profit = 0;
  foreach($orders as $o){
    if(($o['assigned_to'] ?? '') !== $username) continue;
    $profit += order_profit($o);
  }
  return $profit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $action = $_POST['action'] ?? '';
  $id = $_POST['id'] ?? '';

  if($action === 'settle'){
    foreach($users as &$u){
      if(($u['id'] ?? '') === $id){
        $username = $u['username'] ?? '';
        $profitNow = calc_user_profit($username, $orders);
        $u['profit_settled'] = (float)($u['profit_settled'] ?? 0) + $profitNow;
        break;
      }
    }
    unset($u);
    write_json(users_path(), $users);
    redirect('users.php');
  }

  if($action === 'delete'){
    // منع حذف admin
    $new = [];
    foreach($users as $u){
      if(($u['id'] ?? '') === $id){
        if(($u['username'] ?? '') === 'admin'){
          $new[] = $u;
        }
        continue;
      }
      $new[] = $u;
    }
    write_json(users_path(), $new);
    redirect('users.php');
  }
}
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>المستخدمين</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="assets/style.css" rel="stylesheet">
</head>
<body>
<div class="container container-max py-4">
  <?php include __DIR__ . '/navbar.php'; ?>

  <div class="panel mb-3 d-flex justify-content-between align-items-center">
    <div style="font-weight:900; font-size:18px;"><i class="fa-solid fa-users-gear"></i> إضافة مستخدم + الصلاحيات</div>
    <a class="btn btn-outline-secondary btn-fat" href="index.php"><i class="fa-solid fa-ban"></i> إلغاء</a>
  </div>

  <div class="panel mb-3">
    <form class="row g-2" method="POST" action="save_user.php">
      <div class="col-lg-3">
        <label class="form-label">اسم المستخدم</label>
        <input class="form-control field" name="username" required>
      </div>
      <div class="col-lg-3">
        <label class="form-label">الاسم الكامل</label>
        <input class="form-control field" name="full_name" required>
      </div>
      <div class="col-lg-3">
        <label class="form-label">كلمة المرور</label>
        <input class="form-control field" name="password" required>
      </div>
      <div class="col-lg-3">
        <label class="form-label">الدور</label>
        <select class="form-select field" name="role">
          <option value="user">مستخدم</option>
          <option value="admin">مدير</option>
        </select>
      </div>

      <div class="col-12">
        <div class="small-note mb-2">حدد صلاحيات المستخدم:</div>
        <div class="d-flex flex-wrap gap-3">
          <?php
            $perms = [
              'dashboard'=>'لوحة التحكم',
              'add_order'=>'إضافة طلب',
              'orders'=>'الطلبات',
              'products'=>'المنتجات',
              'users'=>'المستخدمين',
              'courier'=>'ربط الشركة',
              'ads'=>'الإعلانات'
            ];
            foreach($perms as $k=>$t):
          ?>
            <label class="form-check">
              <input class="form-check-input" type="checkbox" name="perm[]" value="<?= $k ?>" checked>
              <span class="form-check-label"><?= $t ?></span>
            </label>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="col-12">
        <button class="btn btn-success btn-fat"><i class="fa-solid fa-plus"></i> إضافة مستخدم</button>
      </div>
    </form>
  </div>

  <div class="panel">
    <div style="font-weight:900" class="mb-2">قائمة المستخدمين</div>

    <div class="table-wrap">
      <table class="table table-hover mb-0">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>المستخدم</th>
            <th>الدور</th>
            <th>طلبات جديدة</th>
            <th>عند الشركة</th>
            <th>واصل</th>
            <th>راجع</th>
            <th>الأرباح</th>
            <th>تسديد</th>
            <th>حذف</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach($users as $i=>$usr): ?>
          <?php
            $st = user_stats($usr['username']);
            $profitNow = (float)$st['profit'];
          ?>
          <tr>
            <td><?= $i+1 ?></td>
            <td style="font-weight:900"><?= htmlspecialchars(($usr['full_name'] ?? '') . " ({$usr['username']})") ?></td>
            <td><?= htmlspecialchars($usr['role'] ?? 'user') ?></td>
            <td><?= (int)$st['new'] ?></td>
            <td><?= (int)$st['in_company'] ?></td>
            <td><?= (int)$st['delivered'] ?></td>
            <td><?= (int)$st['returned'] ?></td>
            <td><?= number_format($profitNow) ?></td>
            <td>
              <form method="POST">
                <input type="hidden" name="action" value="settle">
                <input type="hidden" name="id" value="<?= htmlspecialchars($usr['id']) ?>">
                <button class="btn btn-primary btn-fat" onclick="return confirm('تأكيد التسديد؟ سيتم تصفير الأرباح الحالية لهذا المستخدم.');">
                  <i class="fa-solid fa-money-bill-wave"></i>
                </button>
              </form>
            </td>
            <td>
              <form method="POST">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= htmlspecialchars($usr['id']) ?>">
                <button class="btn btn-danger btn-fat" onclick="return confirm('تأكيد حذف المستخدم؟');" <?= ($usr['username']==='admin')?'disabled':'' ?>>
                  <i class="fa-solid fa-trash"></i>
                </button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="small-note mt-2">
      زر التسديد: يسجل أرباح المستخدم كـ (مُسدد) ويبدأ من جديد.
    </div>
  </div>

</div>
</body>
</html>