<?php
require_once __DIR__ . '/auth.php';
require_perm('add_order');

$u = current_user();
$products = read_json(products_path(), []);
$users = read_json(users_path(), []);
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>إضافة طلب</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="assets/style.css" rel="stylesheet">
</head>
<body>
<div class="container container-max py-4">
  <?php include __DIR__ . '/navbar.php'; ?>

  <div class="panel mb-3">
    <div class="d-flex justify-content-between align-items-center">
      <div style="font-weight:900; font-size:18px;">
        <i class="fa-solid fa-cart-plus"></i> إضافة طلب جديد
      </div>
      <a class="btn btn-outline-secondary btn-fat" href="index.php"><i class="fa-solid fa-ban"></i> إلغاء</a>
    </div>
  </div>

  <form class="panel" method="POST" action="save_order.php" id="orderForm">
    <div class="row g-3">
      <div class="col-lg-4">
        <label class="form-label">نوع الطلب</label>
        <select class="form-select field" name="order_type" required>
          <option value="new">جديد</option>
          <option value="replace">استبدال</option>
          <option value="return">استرجاع</option>
        </select>
      </div>

      <div class="col-lg-4">
        <label class="form-label">اسم الزبون</label>
        <input class="form-control field" name="customer_name" required>
      </div>

      <div class="col-lg-4">
        <label class="form-label">رقم الهاتف</label>
        <input class="form-control field" name="phone" required placeholder="07xxxxxxxxx">
      </div>

      <div class="col-lg-4">
        <label class="form-label">المحافظة</label>
        <select class="form-select field" name="city" required>
          <option value="بغداد">بغداد</option>
          <option value="البصرة">البصرة</option>
          <option value="النجف">النجف</option>
          <option value="كربلاء">كربلاء</option>
          <option value="ذي قار">ذي قار</option>
          <option value="نينوى">نينوى</option>
          <option value="اربيل">اربيل</option>
          <option value="السليمانية">السليمانية</option>
          <option value="ديالى">ديالى</option>
          <option value="الانبار">الانبار</option>
          <option value="واسط">واسط</option>
          <option value="ميسان">ميسان</option>
          <option value="الديوانية">الديوانية</option>
          <option value="صلاح الدين">صلاح الدين</option>
          <option value="كركوك">كركوك</option>
          <option value="دهوك">دهوك</option>
          <option value="المثنى">المثنى</option>
          <option value="بابل">بابل</option>
        </select>
      </div>

      <div class="col-lg-4">
        <label class="form-label">المنطقة / الحي</label>
        <input class="form-control field" name="area" required>
      </div>

      <div class="col-lg-4">
        <label class="form-label">العنوان (تفاصيل)</label>
        <input class="form-control field" name="address" required>
      </div>

      <div class="col-lg-4">
        <label class="form-label">المستخدم المسؤول</label>
        <select class="form-select field" name="assigned_to" required>
          <?php foreach($users as $usr): ?>
            <option value="<?= htmlspecialchars($usr['username']) ?>" <?= ($usr['username']===$u['username'])?'selected':'' ?>>
              <?= htmlspecialchars(($usr['full_name'] ?? $usr['username']) . " ({$usr['username']})") ?>
            </option>
          <?php endforeach; ?>
        </select>
        <div class="small-note mt-1">تحديد من يظهر له الطلب وإحصائياته.</div>
      </div>

      <div class="col-lg-8">
        <label class="form-label">ملاحظة</label>
        <input class="form-control field" name="note" placeholder="اختياري">
      </div>

      <div class="col-12"><hr class="soft"></div>

      <div class="col-lg-6">
        <div class="panel">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <div style="font-weight:900"><i class="fa-solid fa-basket-shopping"></i> السلة</div>
            <span class="badge-soft badge-new" id="basketCount">0 منتج</span>
          </div>

          <div id="basketList" class="d-grid gap-2"></div>

          <input type="hidden" name="items_json" id="itemsJson">

          <hr class="soft my-3">

          <div class="row g-2">
            <div class="col-6">
              <label class="form-label">المبلغ الكلي</label>
              <input class="form-control field" name="total" id="total" value="0" required>
            </div>
            <div class="col-6">
              <label class="form-label">الخصم</label>
              <input class="form-control field" name="discount" id="discount" value="0">
            </div>
            <div class="col-6">
              <label class="form-label">المدفوع</label>
              <input class="form-control field" name="paid" id="paid" value="0">
            </div>
            <div class="col-6">
              <label class="form-label">المتبقي</label>
              <input class="form-control field" id="remain" value="0" readonly>
            </div>
          </div>

          <div class="d-flex gap-2 mt-3">
            <a class="btn btn-outline-secondary btn-fat w-50" href="index.php">
              <i class="fa-solid fa-ban"></i> إلغاء
            </a>
            <button class="btn btn-primary btn-fat w-50" type="submit">
              <i class="fa-solid fa-floppy-disk"></i> حفظ الطلب
            </button>
          </div>

        </div>
      </div>

      <div class="col-lg-6">
        <div class="panel">
          <div style="font-weight:900" class="mb-2">
            <i class="fa-solid fa-box"></i> إضافة منتج إلى السلة
          </div>

          <div class="row g-2">
            <div class="col-12">
              <label class="form-label">اسم المنتج</label>
              <select class="form-select field" id="p_id">
                <?php foreach($products as $p): ?>
                  <option value="<?= htmlspecialchars($p['id']) ?>"
                          data-name="<?= htmlspecialchars($p['name']) ?>"
                          data-cost="<?= htmlspecialchars($p['cost']) ?>"
                          data-sell="<?= htmlspecialchars($p['sell']) ?>">
                    <?= htmlspecialchars($p['name']) ?> — بيع: <?= htmlspecialchars($p['sell']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <?php if(empty($products)): ?>
                <div class="small-note mt-1">لا يوجد منتجات. أضف منتجات من صفحة المنتجات أولاً.</div>
              <?php endif; ?>
            </div>

            <div class="col-4">
              <label class="form-label">العدد</label>
              <input class="form-control field" id="p_qty" value="1">
            </div>
            <div class="col-4">
              <label class="form-label">تكلفة</label>
              <input class="form-control field" id="p_cost" value="0">
            </div>
            <div class="col-4">
              <label class="form-label">بيع</label>
              <input class="form-control field" id="p_sell" value="0">
            </div>

            <div class="col-12">
              <button type="button" class="btn btn-success btn-fat w-100" id="addToBasket" <?= empty($products)?'disabled':'' ?>>
                <i class="fa-solid fa-plus"></i> إضافة إلى السلة
              </button>
            </div>
          </div>

          <hr class="soft my-3">
          <div class="small-note">
            ✅ كل منتج بالسلة يظهر مع زر X للحذف.  
            ✅ يمكنك تعديل المبلغ الكلي والخصم والمدفوع يدوياً.
          </div>
        </div>
      </div>

    </div>
  </form>
</div>

<script src="assets/app.js"></script>
<script>
let basket = [];

function updateRemain(){
  const total = Number(qs('total').value || 0);
  const discount = Number(qs('discount').value || 0);
  const paid = Number(qs('paid').value || 0);
  const remain = (total - discount) - paid;
  qs('remain').value = remain;
}

function renderBasket(){
  const list = qs('basketList');
  list.innerHTML = '';
  basket.forEach((it, idx) => {
    const div = document.createElement('div');
    div.className = 'basket-item';
    div.innerHTML = `
      <div>
        <div style="font-weight:800">${it.name}</div>
        <div class="small-note">عدد: ${it.qty} | بيع: ${it.sell} | تكلفة: ${it.cost}</div>
      </div>
      <button type="button" class="xbtn" title="حذف" onclick="removeItem(${idx})">
        <i class="fa-solid fa-xmark"></i>
      </button>
    `;
    list.appendChild(div);
  });

  qs('basketCount').textContent = basket.length + ' منتج';
  qs('itemsJson').value = JSON.stringify(basket);
}

function removeItem(i){
  basket.splice(i,1);
  renderBasket();
}

function autoFillFromSelect(){
  const sel = qs('p_id');
  if(!sel) return;
  const opt = sel.options[sel.selectedIndex];
  qs('p_cost').value = opt.getAttribute('data-cost') || 0;
  qs('p_sell').value = opt.getAttribute('data-sell') || 0;
}
autoFillFromSelect();

qs('p_id').addEventListener('change', autoFillFromSelect);

qs('addToBasket').addEventListener('click', () => {
  const sel = qs('p_id');
  const opt = sel.options[sel.selectedIndex];
  const id = sel.value;
  const name = opt.getAttribute('data-name');
  const qty = Number(qs('p_qty').value || 1);
  const cost = Number(qs('p_cost').value || 0);
  const sell = Number(qs('p_sell').value || 0);

  if(!id || !name) return;

  basket.push({id, name, qty, cost, sell});
  renderBasket();
});

['total','discount','paid'].forEach(id=>{
  qs(id).addEventListener('input', updateRemain);
});
updateRemain();

document.getElementById('orderForm').addEventListener('submit', (e)=>{
  if(basket.length === 0){
    if(!confirm('السلة فارغة. هل تريد حفظ الطلب بدون منتجات؟')) {
      e.preventDefault();
      return;
    }
  }
  qs('itemsJson').value = JSON.stringify(basket);
});
</script>
</body>
</html>