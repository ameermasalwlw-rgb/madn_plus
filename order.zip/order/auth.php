<?php
// auth.php
session_start();

define('BASE_DIR', __DIR__);
define('DATA_DIR', BASE_DIR . DIRECTORY_SEPARATOR . 'data');
define('UPLOADS_DIR', BASE_DIR . DIRECTORY_SEPARATOR . 'uploads');

function read_json($path, $default){
  if(!file_exists($path)) return $default;
  $raw = file_get_contents($path);
  $decoded = json_decode($raw, true);

  // حماية من ملفات JSON خاطئة (ترجع string)
  if($decoded === null || is_string($decoded)) return $default;
  return $decoded;
}

function write_json($path, $data){
  $dir = dirname($path);
  if(!is_dir($dir)) mkdir($dir, 0777, true);

  $fp = fopen($path, 'c+');
  if(!$fp) return false;
  flock($fp, LOCK_EX);
  ftruncate($fp, 0);
  fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
  fflush($fp);
  flock($fp, LOCK_UN);
  fclose($fp);
  return true;
}

function redirect($to){
  header("Location: $to");
  exit;
}

function current_user(){
  return $_SESSION['user'] ?? null;
}

function is_logged_in(){
  return isset($_SESSION['user']) && is_array($_SESSION['user']);
}

function require_login(){
  if(!is_logged_in()){
    redirect('login.php');
  }
}

function has_perm($perm){
  $u = current_user();
  if(!$u) return false;
  if(($u['role'] ?? '') === 'admin') return true;
  return !empty($u['permissions'][$perm]);
}

function require_perm($perm){
  require_login();
  if(!has_perm($perm)){
    http_response_code(403);
    echo "403 - لا تملك صلاحية الوصول.";
    exit;
  }
}

function users_path(){ return DATA_DIR . DIRECTORY_SEPARATOR . 'users.json'; }
function orders_path(){ return DATA_DIR . DIRECTORY_SEPARATOR . 'orders.json'; }
function products_path(){ return DATA_DIR . DIRECTORY_SEPARATOR . 'products.json'; }
function courier_path(){ return DATA_DIR . DIRECTORY_SEPARATOR . 'courier.json'; }
function ads_path(){ return DATA_DIR . DIRECTORY_SEPARATOR . 'ads.json'; }

function find_user_by_username($username){
  $users = read_json(users_path(), []);
  foreach($users as $u){
    if(($u['username'] ?? '') === $username) return $u;
  }
  return null;
}

function verify_password($plain, $hash){
  // يدعم hash bcrypt
  if(is_string($hash) && (strpos($hash, '$2y$') === 0 || strpos($hash, '$2b$') === 0)){
    return password_verify($plain, $hash);
  }
  // fallback (لو كان نص عادي)
  return $plain === $hash;
}

function status_label($s){
  switch($s){
    case 'new': return 'جديد';
    case 'in_company': return 'عند الشركة';
    case 'delivered': return 'واصل';
    case 'returned': return 'راجع';
    default: return $s;
  }
}

function status_badge_class($s){
  switch($s){
    case 'new': return 'badge-new';
    case 'in_company': return 'badge-company';
    case 'delivered': return 'badge-delivered';
    case 'returned': return 'badge-returned';
    default: return 'badge-new';
  }
}

function order_profit($order){
  $items = $order['items'] ?? [];
  $profit = 0;
  foreach($items as $it){
    $qty = (float)($it['qty'] ?? 0);
    $sell = (float)($it['sell'] ?? 0);
    $cost = (float)($it['cost'] ?? 0);
    $profit += ($sell - $cost) * $qty;
  }
  $discount = (float)($order['discount'] ?? 0);
  $profit -= $discount;
  return $profit;
}

function user_stats($username){
  $orders = read_json(orders_path(), []);
  $stats = [
    'new'=>0,'in_company'=>0,'delivered'=>0,'returned'=>0,
    'profit'=>0
  ];
  foreach($orders as $o){
    if(($o['assigned_to'] ?? '') !== $username) continue;
    $st = $o['status'] ?? 'new';
    if(isset($stats[$st])) $stats[$st] += 1;
    $stats['profit'] += order_profit($o);
  }
  return $stats;
}