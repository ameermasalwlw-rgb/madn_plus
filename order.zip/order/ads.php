<?php
require_once __DIR__ . '/auth.php';
require_perm('ads');

$cfg = read_json(ads_path(), ["interval_ms"=>3000,"images"=>[]]);
$imgs = $cfg['images'] ?? [];
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>الإعلانات</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="assets/style.css" rel="stylesheet">
</head>
<body>
<div class="container container-max py-4">
  <?php include __DIR__ . '/navbar.php'; ?>

  <div class="panel mb-3 d-flex justify-content-between align-items-center">
    <div style="font-weight:900; font-size:18px;"><i class="fa-solid fa-bullhorn"></i> الإعلانات</div>
    <a class="btn btn-outline-secondary btn-fat" href="index.php"><i class="fa-solid fa-ban"></i> إلغاء</a>
  </div>

  <div class="panel mb-3">
    <form method="POST" action="save_ad.php" enctype="multipart/form-data" class="row g-2">
      <div class="col-lg-4">
        <label class="form-label">سرعة التقليب (ms)</label>
        <input class="form-control field" name="interval_ms" value="<?= (int)($cfg['interval_ms'] ?? 3000) ?>">
      </div>
      <div class="col-lg-8">
        <label class="form-label">إضافة صور (عدة صور)</label>
        <input class="form-control field" type="file" name="images[]" accept="image/*" multiple>
      </div>

      <div class="col-12 d-flex gap-2">
        <a class="btn btn-outline-secondary btn-fat w-50" href="index.php"><i class="fa-solid fa-ban"></i> إلغاء</a>
        <button class="btn btn-success btn-fat w-50"><i class="fa-solid fa-floppy-disk"></i> حفظ</button>
      </div>
    </form>
  </div>

  <div class="panel">
    <div style="font-weight:900" class="mb-2">الصور الحالية</div>
    <div class="row g-2">
      <?php if(empty($imgs)): ?>
        <div class="small-note p-3">لا توجد صور.</div>
      <?php endif; ?>
      <?php foreach($imgs as $img): ?>
        <div class="col-6 col-lg-3">
          <img src="<?= htmlspecialchars($img) ?>" style="width:100%;height:160px;border-radius:18px;object-fit:cover;border:1px solid #e5e7eb;">
        </div>
      <?php endforeach; ?>
    </div>
  </div>

</div>
</body>
</html>