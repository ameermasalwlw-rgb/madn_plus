<?php
require_once __DIR__ . '/auth.php';

if(is_logged_in()){
  redirect('index.php');
}

$error = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $username = trim($_POST['username'] ?? '');
  $password = trim($_POST['password'] ?? '');

  $u = find_user_by_username($username);
  if($u && verify_password($password, $u['password_hash'] ?? '')){
    // خزّن بيانات آمنة بالجلسة
    $_SESSION['user'] = [
      'id' => $u['id'] ?? '',
      'username' => $u['username'] ?? '',
      'full_name' => $u['full_name'] ?? '',
      'role' => $u['role'] ?? 'user',
      'permissions' => $u['permissions'] ?? []
    ];
    redirect('index.php');
  }else{
    $error = 'اسم المستخدم أو كلمة المرور غير صحيحة.';
  }
}
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>تسجيل الدخول</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="assets/style.css" rel="stylesheet">
</head>
<body>
  <div class="container container-max py-5">
    <div class="row justify-content-center">
      <div class="col-lg-5">
        <div class="panel">
          <div class="text-center mb-3">
            <div class="brand justify-content-center">
              <div class="logo"><i class="fa-solid fa-box"></i></div>
              <div>
                <div style="font-size:20px;">نظام الطلبات</div>
                <div class="small-note">تسجيل الدخول</div>
              </div>
            </div>
          </div>

          <?php if($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
          <?php endif; ?>

          <form method="POST">
            <div class="mb-3">
              <label class="form-label">اسم المستخدم</label>
              <input name="username" class="form-control field" required>
            </div>
            <div class="mb-3">
              <label class="form-label">كلمة المرور</label>
              <input name="password" type="password" class="form-control field" required>
            </div>

            <button class="btn btn-primary btn-fat w-100">
              <i class="fa-solid fa-right-to-bracket"></i> دخول
            </button>

            <hr class="soft my-4">
            <div class="small-note">
              افتراضي: <b>admin</b> / <b>admin123</b>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</body>
</html>