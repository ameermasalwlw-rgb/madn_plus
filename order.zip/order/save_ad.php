<?php
require_once __DIR__ . '/auth.php';
require_perm('ads');

if($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('ads.php');

$cfg = read_json(ads_path(), ["interval_ms"=>3000,"images"=>[]]);
if(!is_array($cfg)) $cfg = ["interval_ms"=>3000,"images"=>[]];

$cfg['interval_ms'] = (int)($_POST['interval_ms'] ?? 3000);
if(!isset($cfg['images']) || !is_array($cfg['images'])) $cfg['images'] = [];

if(!empty($_FILES['images']['name'][0])){
  $destDir = __DIR__ . '/uploads/ads';
  if(!is_dir($destDir)) mkdir($destDir, 0777, true);

  for($i=0; $i<count($_FILES['images']['name']); $i++){
    $tmp = $_FILES['images']['tmp_name'][$i];
    if(!is_uploaded_file($tmp)) continue;

    $ext = pathinfo($_FILES['images']['name'][$i], PATHINFO_EXTENSION);
    $fname = 'ad_' . time() . '_' . rand(1000,9999) . '.' . $ext;
    $dest = $destDir . '/' . $fname;
    move_uploaded_file($tmp, $dest);

    $cfg['images'][] = 'uploads/ads/' . $fname;
  }
}

write_json(ads_path(), $cfg);
redirect('ads.php');