<?php
require_once __DIR__ . '/auth.php';
require_perm('courier');

$cfg = read_json(courier_path(), [
  "enabled"=>false,"company_name"=>"","api_base_url"=>"","api_key"=>"",
  "sender_name"=>"","sender_phone"=>"","sender_city"=>"","notes"=>""
]);
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ربط شركة التوصيل</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="assets/style.css" rel="stylesheet">
</head>
<body>
<div class="container container-max py-4">
  <?php include __DIR__ . '/navbar.php'; ?>

  <div class="panel mb-3 d-flex justify-content-between align-items-center">
    <div style="font-weight:900; font-size:18px;"><i class="fa-solid fa-link"></i> ربط شركة التوصيل</div>
    <a class="btn btn-outline-secondary btn-fat" href="index.php"><i class="fa-solid fa-ban"></i> إلغاء</a>
  </div>

  <div class="panel">
    <form class="row g-2" method="POST" action="save_courier.php">
      <div class="col-12">
        <label class="form-check">
          <input class="form-check-input" type="checkbox" name="enabled" <?= !empty($cfg['enabled'])?'checked':'' ?>>
          <span class="form-check-label">تفعيل الربط</span>
        </label>
      </div>

      <div class="col-lg-4">
        <label class="form-label">اسم الشركة</label>
        <input class="form-control field" name="company_name" value="<?= htmlspecialchars($cfg['company_name'] ?? '') ?>">
      </div>
      <div class="col-lg-4">
        <label class="form-label">API Base URL</label>
        <input class="form-control field" name="api_base_url" value="<?= htmlspecialchars($cfg['api_base_url'] ?? '') ?>" placeholder="https://api.company.com">
      </div>
      <div class="col-lg-4">
        <label class="form-label">API Key</label>
        <input class="form-control field" name="api_key" value="<?= htmlspecialchars($cfg['api_key'] ?? '') ?>">
      </div>

      <div class="col-lg-4">
        <label class="form-label">اسم المرسل</label>
        <input class="form-control field" name="sender_name" value="<?= htmlspecialchars($cfg['sender_name'] ?? '') ?>">
      </div>
      <div class="col-lg-4">
        <label class="form-label">هاتف المرسل</label>
        <input class="form-control field" name="sender_phone" value="<?= htmlspecialchars($cfg['sender_phone'] ?? '') ?>">
      </div>
      <div class="col-lg-4">
        <label class="form-label">مدينة المرسل</label>
        <input class="form-control field" name="sender_city" value="<?= htmlspecialchars($cfg['sender_city'] ?? '') ?>">
      </div>

      <div class="col-12">
        <label class="form-label">ملاحظات</label>
        <textarea class="form-control field" rows="3" name="notes"><?= htmlspecialchars($cfg['notes'] ?? '') ?></textarea>
      </div>

      <div class="col-12 d-flex gap-2">
        <a class="btn btn-outline-secondary btn-fat w-50" href="index.php"><i class="fa-solid fa-ban"></i> إلغاء</a>
        <button class="btn btn-success btn-fat w-50"><i class="fa-solid fa-floppy-disk"></i> حفظ</button>
      </div>

      <div class="col-12 small-note mt-2">
        هذا نموذج “ربط”. عند توفر API حقيقي للشركة نضيف طلب الإرسال/تتبع تلقائياً.
      </div>
    </form>
  </div>

</div>
</body>
</html>