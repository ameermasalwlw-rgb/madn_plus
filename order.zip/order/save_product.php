<?php
require_once __DIR__ . '/auth.php';
require_perm('products');

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
  redirect('products.php');
}

$products = read_json(products_path(), []);
if(!is_array($products)) $products = [];

$name = trim($_POST['name'] ?? '');
$stock = (int)($_POST['stock'] ?? 0);
$cost = (float)($_POST['cost'] ?? 0);
$sell = (float)($_POST['sell'] ?? 0);

$imagePath = '';
if(!empty($_FILES['image']['name'])){
  $tmp = $_FILES['image']['tmp_name'];
  if(is_uploaded_file($tmp)){
    $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
    $fname = 'p_' . time() . '_' . rand(1000,9999) . '.' . $ext;

    $destDir = __DIR__ . '/uploads/products';
    if(!is_dir($destDir)) mkdir($destDir, 0777, true);

    $dest = $destDir . '/' . $fname;
    move_uploaded_file($tmp, $dest);
    $imagePath = 'uploads/products/' . $fname;
  }
}

$products[] = [
  'id' => 'p_' . time() . '_' . rand(1000,9999),
  'name' => $name,
  'stock' => $stock,
  'cost' => $cost,
  'sell' => $sell,
  'image' => $imagePath
];

write_json(products_path(), $products);
redirect('products.php');